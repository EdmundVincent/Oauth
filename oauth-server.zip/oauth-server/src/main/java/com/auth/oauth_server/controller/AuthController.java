package com.auth.oauth_server.controller;

import com.auth.oauth_server.entity.User; // 引入 User 实体
import com.auth.oauth_server.repository.UserRepository; // 引入仓库
import com.auth.oauth_server.service.AuthService;
import com.auth.oauth_server.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.RedirectView;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private AuthService authService;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private UserRepository userRepository; // 注入仓库管理员，用来查数据库

    // --- 1. 展示登录页面 ---
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // 这里会自动去 templates 文件夹找 login.html
    }

    // --- 2. 处理登录请求 (前端表单提交到这里) ---
    @PostMapping("/login-action")
    public Object handleLogin(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String redirect_uri,
            @RequestParam String state,
            Model model // 用来给页面传消息
    ) {
        // A. 去数据库查这个用户
        Optional<User> userOptional = userRepository.findByUsername(username);

        // B. 检查用户是否存在，以及密码是否对 (注意：真实项目密码要加密，这里演示用明文)
        if (userOptional.isPresent() && userOptional.get().getPassword().equals(password)) {
            // --- 登录成功！ ---
            System.out.println("Jarvis: 用户 " + username + " 验证通过！");

            // 生成 Code
            String code = authService.createAuthorizationCode(username);
            
            // 跳回原来的 redirect_uri
            String finalUrl = String.format("%s?code=%s&state=%s", redirect_uri, code, state);
            return new RedirectView(finalUrl);
        } else {
            // --- 登录失败 ---
            System.out.println("Jarvis: 用户 " + username + " 登录失败！");
            
            // 告诉页面显示错误信息
            model.addAttribute("error", "账号或密码错误！");
            return "login"; // 停留在登录页
        }
    }

    // --- 3. 兑换 Token (保持不变) ---
    @PostMapping("/oauth/token")
    @ResponseBody
    public ResponseEntity<?> getToken(@RequestParam String code) {
        String username = authService.consumeCode(code);
        if (username == null) return ResponseEntity.status(400).body("Error: Code 无效");
        
        String token = jwtService.generateToken(username);
        Map<String, String> response = new HashMap<>();
        response.put("access_token", token);
        return ResponseEntity.ok(response);
    }
    // --- 4. 登录成功后的回调页面 (新增) ---
    // 这是为了让您看到漂亮的网页，而不是报错页
   // --- 4. 登录成功后的回调页面 (超级增强版) ---
    // --- 4. 登录成功后的回调页面 (修复版：修复了 JS 丢失的问题) ---
    @GetMapping("/callback")
    @ResponseBody
    public String callbackPage(@RequestParam String code, @RequestParam String state) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<meta charset='UTF-8'>" + // 防止乱码
                "<style>" +
                "body { font-family: 'Segoe UI', sans-serif; text-align: center; padding-top: 50px; background-color: #f4f6f9; }" +
                ".box { background: white; padding: 40px; border-radius: 12px; width: 600px; display: inline-block; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }" +
                "h1 { color: #2e7d32; margin-bottom: 5px; } h3 { margin-top: 20px; color: #555; }" +
                ".code-box { background: #fff3e0; color: #e65100; padding: 10px; border-radius: 4px; font-family: monospace; word-break: break-all; margin: 10px 0; border: 1px solid #ffe0b2; }" +
                ".token-box { background: #e8eaf6; color: #1a237e; padding: 10px; border-radius: 4px; font-family: monospace; word-break: break-all; margin: 10px 0; border: 1px solid #c5cae9; display: none; }" +
                ".result-box { background: #e8f5e9; color: #1b5e20; padding: 15px; border-radius: 4px; margin-top: 15px; display: none; border: 1px solid #c8e6c9; font-weight: bold; text-align: left; }" +
                "button { padding: 12px 24px; font-size: 16px; cursor: pointer; border: none; border-radius: 6px; margin: 5px; transition: 0.3s; }" +
                ".btn-exchange { background-color: #1976d2; color: white; } .btn-exchange:hover { background-color: #1565c0; }" +
                ".btn-test { background-color: #ff9800; color: white; display: none; } .btn-test:hover { background-color: #f57c00; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "  <div class='box'>" +
                "    <h1>🎉 授权成功 (Phase 1)</h1>" +
                "    <p>服务端已发放授权码 (Code):</p>" +
                "    <div class='code-box' id='auth-code'>" + code + "</div>" +
                
                "    " +
                "    <div style='margin-top: 20px;'>" +
                "       <button onclick='exchangeToken()' class='btn-exchange'>🚀 一键兑换 Token</button>" +
                "       <button onclick='accessVipResource()' id='btn-vip' class='btn-test'>🕵️‍♂️ 访问 VIP 接口</button>" +
                "    </div>" +

                "    " +
                "    <div id='token-area' style='display:none'>" +
                "       <h3>🎫 您的通行证 (Token):</h3>" +
                "       <div class='token-box' id='access-token'></div>" +
                "    </div>" +

                "    " +
                "    <div id='vip-result' class='result-box'></div>" +
                "  </div>" +

                // --- 关键修复：确保 Script 标签正确拼接 ---
                "  <script>" +
                "    var globalToken = '';" + 
                
                "    function exchangeToken() {" +
                "       var code = document.getElementById('auth-code').innerText;" +
                "       var btn = document.querySelector('.btn-exchange');" +
                "       btn.disabled = true;" +
                "       btn.innerText = '⏳ 兑换中...';" +

                "       fetch('/oauth/token?grant_type=authorization_code&code=' + code, { method: 'POST' })" +
                "           .then(async res => {" +
                "               const text = await res.text();" + // 先拿文本，防止 JSON 解析挂掉
                "               try {" +
                "                   const data = JSON.parse(text);" +
                "                   if(data.access_token) {" +
                "                       globalToken = data.access_token;" +
                "                       document.getElementById('access-token').innerText = globalToken;" +
                "                       document.getElementById('access-token').style.display = 'block';" +
                "                       document.getElementById('token-area').style.display = 'block';" +
                "                       document.getElementById('btn-vip').style.display = 'inline-block';" +
                "                       btn.innerText = '✅ 兑换成功';" +
                "                   } else {" +
                "                       throw new Error('No Token');" +
                "                   }" +
                "               } catch (e) {" +
                "                   alert('兑换失败: ' + text);" + // 失败时弹出原始文本
                "                   btn.innerText = '❌ 失败 (重试)';" +
                "                   btn.disabled = false;" +
                "               }" +
                "           })" +
                "           .catch(err => {" +
                "               alert('网络错误: ' + err);" +
                "               btn.disabled = false;" +
                "           });" +
                "    }" +

                "    function accessVipResource() {" +
                "       if(!globalToken) { alert('请先兑换 Token'); return; }" +
                "       fetch('/api/profile', {" +
                "           method: 'GET'," +
                "           headers: { 'Authorization': 'Bearer ' + globalToken }" +
                "       })" +
                "       .then(res => res.text())" +
                "       .then(text => {" +
                "           var resultBox = document.getElementById('vip-result');" +
                "           resultBox.style.display = 'block';" +
                "           resultBox.innerText = '🛡️ 服务器回应: ' + text;" +
                "       });" +
                "    }" +
                "  </script>" +
                "</body></html>";
    }
}