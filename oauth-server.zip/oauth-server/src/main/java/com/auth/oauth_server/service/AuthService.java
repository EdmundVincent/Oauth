package com.auth.oauth_server.service;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {

    // 这是一个内存字典，用来存放 code -> username 的对应关系
    // Key: code (票据), Value: username (是谁申请的)
    private final Map<String, String> codeStore = new ConcurrentHashMap<>();

    /**
     * 生成一个授权码，并记录是谁申请的
     */
    public String createAuthorizationCode(String username) {
        // 生成一个随机的字符串，比如 "a1b2-c3d4..."
        String code = UUID.randomUUID().toString();
        
        // 存入内存，以后拿 code 就能查到是哪个用户
        codeStore.put(code, username);
        
        System.out.println("Jarvis: Generated code for " + username + ": " + code);
        return code;
    }

    /**
     * 验证 code 是否有效，如果有效则返回 username，并销毁 code (一次性使用)
     */
    public String consumeCode(String code) {
        return codeStore.remove(code); // 拿走并删除
    }
}